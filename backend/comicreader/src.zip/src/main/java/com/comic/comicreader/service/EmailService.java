package com.comic.comicreader.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendRegistrationOtp(String email, String otp) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(email);
        message.setSubject("City of Comics - Email Verification");

        message.setText(
                "Welcome to City of Comics!\n\n"
                + "Your email verification OTP is:\n\n"
                + otp
                + "\n\n"
                + "This OTP is valid for 10 minutes.\n"
                + "You have a maximum of 5 verification attempts.\n\n"
                + "If you did not request this registration, you can safely ignore this email."
        );

        mailSender.send(message);
    }
}